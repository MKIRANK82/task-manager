from datetime import datetime , date
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates


from app.config.dependencies import (
    get_task_activity_service,
    get_task_dependency_service,
    get_task_service,
)

from app.models.task_dependency import (
    TaskDependencyCreate,
)

from app.services.task_dependency_service import (
    TaskDependencyService,
)
from app.models.task import (
    TaskCreate,
    TaskPriority,
    TaskStatus,
    TaskType,
    TaskUpdate,
)
from app.services.task_service import TaskService

from app.models.task_activity import (
    ActivityType,
    TaskActivityCreate,
)

from app.services.task_activity_service import (
    TaskActivityService,
)

router = APIRouter(tags=["UI"])

templates = Jinja2Templates(directory="templates")


@router.get(
    "/dashboard",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def dashboard(
    request: Request,
    view: str = "all",
    service: TaskService = Depends(
        get_task_service
    ),
) -> HTMLResponse:
    allowed_views = {
        "all",
        "today",
    }

    if view not in allowed_views:
        view = "all"

    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "dashboard": service.get_dashboard(),
            "task_tree": service.get_tree(view),
            "current_view": view,
            "today_date": date.today(),
        },
    )


@router.get(
    "/ui/tasks/tree",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def task_tree(
    request: Request,
    view: str = "all",
    service: TaskService = Depends(
        get_task_service
    ),
) -> HTMLResponse:
    if view not in {"all", "today"}:
        view = "all"

    return templates.TemplateResponse(
        request=request,
        name="task_tree.html",
        context={
            "task_tree": service.get_tree(view),
            "today_date": date.today(),
        },
    )

@router.get(
    "/tasks/new",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def create_task_page(
    request: Request,
    service: TaskService = Depends(get_task_service),
) -> HTMLResponse:
    parent_task_id_value = request.query_params.get(
        "parent_task_id",
        "0",
    )

    try:
        parent_task_id = int(parent_task_id_value)
    except ValueError:
        parent_task_id = 0

    parent_task = None

    if parent_task_id != 0:
        parent_task = service.get_by_id(parent_task_id)

        if parent_task is None:
            parent_task_id = 0

    return render_create_form(
        request=request,
        parent_task_id=parent_task_id,
        parent_task=parent_task,
    )

@router.post(
    "/tasks/new",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def create_task_from_form(
    request: Request,
    parent_task_id: int = Form(default=0),
    short_description: str = Form(...),
    description: str = Form(default=""),
    task_status: str = Form(default="not_started"),
    priority: str = Form(default="medium"),
    task_type: str = Form(default="task"),
    category: str = Form(default=""),
    tags: str = Form(default=""),
    planned_start_date: str = Form(default=""),
    planned_end_date: str = Form(default=""),
    due_date: str = Form(default=""),
    estimated_effort_hours: str = Form(default=""),
    assigned_to: str = Form(default="Kiran"),
    team: str = Form(default=""),
    created_by: str = Form(default="Kiran"),
    service: TaskService = Depends(get_task_service),
) -> HTMLResponse:
    form_values = {
        "parent_task_id": parent_task_id,
        "short_description": short_description,
        "description": description,
        "task_status": task_status,
        "priority": priority,
        "task_type": task_type,
        "category": category,
        "tags": tags,
        "planned_start_date": planned_start_date,
        "planned_end_date": planned_end_date,
        "due_date": due_date,
        "estimated_effort_hours": estimated_effort_hours,
        "assigned_to": assigned_to,
        "team": team,
        "created_by": created_by,
    }

    try:
        cleaned_short_description = short_description.strip()

        if not cleaned_short_description:
            raise ValueError(
                "Short description is required."
            )

        estimated_hours = parse_float(
            estimated_effort_hours
        )

        task_create = TaskCreate(
            parent_task_id=parent_task_id,
            short_description=cleaned_short_description,
            description=empty_to_none(description),
            status=TaskStatus(task_status),
            priority=TaskPriority(priority),
            task_type=TaskType(task_type),
            category=empty_to_none(category),
            tags=parse_tags(tags),
            planned_start_date=parse_datetime(
                planned_start_date
            ),
            planned_end_date=parse_datetime(
                planned_end_date
            ),
            due_date=parse_datetime(due_date),
            estimated_effort_hours=estimated_hours,
            actual_effort_hours=0,
            remaining_effort_hours=estimated_hours,
            progress_percentage=0,
            assigned_to=empty_to_none(assigned_to),
            team=empty_to_none(team),
            created_by=created_by.strip() or "Kiran",
        )

        created_task = service.create(task_create)

    except (ValueError, TypeError) as error:
        parent_task = None

        if parent_task_id != 0:
            parent_task = service.get_by_id(parent_task_id)

        return render_create_form(
            request=request,
            parent_task_id=parent_task_id,
            parent_task=parent_task,
            form_values=form_values,
            error_message=str(error),
            status_code=400,
        )
    return RedirectResponse(
        url=f"/tasks/{created_task.task_id}?created=true",
        status_code=303,
    )



@router.get(
    "/tasks/{task_id}",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def task_details(
    request: Request,
    task_id: int,
    service: TaskService = Depends(get_task_service),
    activity_service: TaskActivityService = Depends(
        get_task_activity_service
    ),
    dependency_service: TaskDependencyService = Depends(
        get_task_dependency_service
    ),
) -> HTMLResponse:
    task_entity = service.get_by_id(task_id)

    if task_entity is None:
        return templates.TemplateResponse(
            request=request,
            name="task_not_found.html",
            context={
                "task_id": task_id,
            },
            status_code=404,
        )

    parent_task = None

    if task_entity.parent_task_id != 0:
        parent_task = service.get_by_id(
            task_entity.parent_task_id
        )
    dependencies = (
        dependency_service.get_dependencies(
            task_id
        )
    )

    required_by = (
        dependency_service.get_required_by(
            task_id
        )
    )

    dependency_state = (
        dependency_service.get_dependency_state(
            task_id
        )
    )
    return templates.TemplateResponse(
        request=request,
        name="task_details.html",
        context={
            "task": task_entity,
            "parent_task": parent_task,
            "child_tasks": service.get_children(task_id),
            "activities": (
                activity_service.get_by_task_id(task_id)
            ),
            # Dependency information
            "dependencies": dependencies,
            "required_by": required_by,
            "dependency_state": dependency_state,

            "updated": (
                request.query_params.get("updated")
                == "true"
            ),
            "created": (
                request.query_params.get("created")
                == "true"
            ),
            "comment_added": (
                request.query_params.get("comment_added")
                == "true"
            ),
            "can_delete": service.can_delete_hierarchy(
                    task_id
                )[0],

                "delete_reason": service.can_delete_hierarchy(
                    task_id
                )[1],

                "delete_error": request.query_params.get(
                    "delete_error"
                ),

                "deleted": (
                    request.query_params.get("deleted")
                    == "true"
                ),

                "deleted_count": request.query_params.get(
                    "deleted_count"
                ),
        },
    )



@router.post(
    "/tasks/{task_id}/delete",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def delete_task_hierarchy(
    request: Request,
    task_id: int,
    deleted_by: str = Form(default="Kiran"),
    service: TaskService = Depends(
        get_task_service
    ),
) -> HTMLResponse:
    task = service.get_by_id(task_id)

    if task is None:
        return templates.TemplateResponse(
            request=request,
            name="task_not_found.html",
            context={
                "task_id": task_id,
            },
            status_code=404,
        )

    parent_task_id = task.parent_task_id

    try:
        result = service.delete_hierarchy(
            task_id=task_id,
            deleted_by=(
                deleted_by.strip() or "Kiran"
            ),
        )

    except ValueError as error:
        return RedirectResponse(
            url=(
                f"/tasks/{task_id}"
                f"?delete_error={quote(str(error))}"
            ),
            status_code=303,
        )

    if parent_task_id != 0:
        return RedirectResponse(
            url=(
                f"/tasks/{parent_task_id}"
                f"?deleted=true"
                f"&deleted_count="
                f"{result['deleted_task_count']}"
            ),
            status_code=303,
        )

    return RedirectResponse(
        url=(
            "/dashboard"
            "?deleted=true"
            f"&deleted_count="
            f"{result['deleted_task_count']}"
        ),
        status_code=303,
    )

@router.post(
    "/tasks/{task_id}/activities",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def add_task_activity(
    request: Request,
    task_id: int,
    message: str = Form(...),
    created_by: str = Form(default="Kiran"),
    service: TaskService = Depends(get_task_service),
    activity_service: TaskActivityService = Depends(
        get_task_activity_service
    ),
) -> HTMLResponse:
    task = service.get_by_id(task_id)

    if task is None:
        return templates.TemplateResponse(
            request=request,
            name="task_not_found.html",
            context={
                "task_id": task_id,
            },
            status_code=404,
        )

    cleaned_message = message.strip()

    if not cleaned_message:
        return RedirectResponse(
            url=f"/tasks/{task_id}?comment_error=true",
            status_code=303,
        )

    activity_service.create(
        TaskActivityCreate(
            task_id=task_id,
            activity_type=ActivityType.COMMENT,
            title="Comment",
            message=cleaned_message,
            created_by=created_by.strip() or "Kiran",
        )
    )

    return RedirectResponse(
        url=f"/tasks/{task_id}?comment_added=true",
        status_code=303,
    )

@router.get(
    "/tasks/{task_id}/edit",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def edit_task_page(
    request: Request,
    task_id: int,
    service: TaskService = Depends(get_task_service),
) -> HTMLResponse:
    task = service.get_by_id(task_id)

    if task is None:
        return templates.TemplateResponse(
            request=request,
            name="task_not_found.html",
            context={
                "task_id": task_id,
            },
            status_code=404,
        )

    return render_edit_form(
        request=request,
        task=task,
    )


@router.post(
    "/tasks/{task_id}/edit",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def update_task_from_form(
    request: Request,
    task_id: int,
    parent_task_id: int = Form(...),
    short_description: str = Form(...),
    description: str = Form(default=""),
    task_status: str = Form(...),
    priority: str = Form(...),
    task_type: str = Form(...),
    category: str = Form(default=""),
    tags: str = Form(default=""),
    planned_start_date: str = Form(default=""),
    planned_end_date: str = Form(default=""),
    actual_start_date: str = Form(default=""),
    actual_end_date: str = Form(default=""),
    due_date: str = Form(default=""),
    estimated_effort_hours: str = Form(default=""),
    actual_effort_hours: str = Form(default=""),
    remaining_effort_hours: str = Form(default=""),
    progress_percentage: int = Form(default=0),
    assigned_to: str = Form(default=""),
    team: str = Form(default=""),
    blocked_reason: str = Form(default=""),
    external_reference: str = Form(default=""),
    service: TaskService = Depends(get_task_service),
) -> HTMLResponse:
    existing_task = service.get_by_id(task_id)

    if existing_task is None:
        return templates.TemplateResponse(
            request=request,
            name="task_not_found.html",
            context={
                "task_id": task_id,
            },
            status_code=404,
        )

    try:
        task_update = TaskUpdate(
            parent_task_id=parent_task_id,
            short_description=short_description.strip(),
            description=empty_to_none(description),
            status=TaskStatus(task_status),
            priority=TaskPriority(priority),
            task_type=TaskType(task_type),
            category=empty_to_none(category),
            tags=parse_tags(tags),
            planned_start_date=parse_datetime(
                planned_start_date
            ),
            planned_end_date=parse_datetime(
                planned_end_date
            ),
            actual_start_date=parse_datetime(
                actual_start_date
            ),
            actual_end_date=parse_datetime(
                actual_end_date
            ),
            due_date=parse_datetime(due_date),
            estimated_effort_hours=parse_float(
                estimated_effort_hours
            ),
            actual_effort_hours=parse_float(
                actual_effort_hours
            ),
            remaining_effort_hours=parse_float(
                remaining_effort_hours
            ),
            progress_percentage=progress_percentage,
            assigned_to=empty_to_none(assigned_to),
            team=empty_to_none(team),
            blocked_reason=empty_to_none(
                blocked_reason
            ),
            external_reference=empty_to_none(
                external_reference
            ),
        )

        updated_task = service.update(
            task_id,
            task_update,
        )

        if updated_task is None:
            return templates.TemplateResponse(
                request=request,
                name="task_not_found.html",
                context={
                    "task_id": task_id,
                },
                status_code=404,
            )

    except (ValueError, TypeError) as error:
        form_task = build_form_task(
            existing_task=existing_task,
            parent_task_id=parent_task_id,
            short_description=short_description,
            description=description,
            task_status=task_status,
            priority=priority,
            task_type=task_type,
            category=category,
            tags=tags,
            planned_start_date=planned_start_date,
            planned_end_date=planned_end_date,
            actual_start_date=actual_start_date,
            actual_end_date=actual_end_date,
            due_date=due_date,
            estimated_effort_hours=(
                estimated_effort_hours
            ),
            actual_effort_hours=(
                actual_effort_hours
            ),
            remaining_effort_hours=(
                remaining_effort_hours
            ),
            progress_percentage=(
                progress_percentage
            ),
            assigned_to=assigned_to,
            team=team,
            blocked_reason=blocked_reason,
            external_reference=external_reference,
        )

        return render_edit_form(
            request=request,
            task=form_task,
            error_message=str(error),
            status_code=400,
        )

    return RedirectResponse(
        url=f"/tasks/{task_id}?updated=true",
        status_code=303,
    )

def render_create_form(
    *,
    request: Request,
    parent_task_id: int = 0,
    parent_task: object | None = None,
    form_values: dict[str, object] | None = None,
    error_message: str | None = None,
    status_code: int = 200,
) -> HTMLResponse:
    values = form_values or {}

    return templates.TemplateResponse(
        request=request,
        name="task_create.html",
        context={
            "statuses": list(TaskStatus),
            "priorities": list(TaskPriority),
            "task_types": list(TaskType),
            "parent_task_id": parent_task_id,
            "parent_task": parent_task,
            "form": values,
            "error_message": error_message,
        },
        status_code=status_code,
    )

def render_edit_form(
    *,
    request: Request,
    task: object,
    error_message: str | None = None,
    status_code: int = 200,
) -> HTMLResponse:
    return templates.TemplateResponse(
        request=request,
        name="task_edit.html",
        context={
            "task": task,
            "statuses": list(TaskStatus),
            "priorities": list(TaskPriority),
            "task_types": list(TaskType),
            "error_message": error_message,
        },
        status_code=status_code,
    )


def parse_datetime(
    value: str,
) -> datetime | None:
    cleaned_value = value.strip()

    if not cleaned_value:
        return None

    return datetime.fromisoformat(cleaned_value)


def parse_float(
    value: str,
) -> float | None:
    cleaned_value = value.strip()

    if not cleaned_value:
        return None

    return float(cleaned_value)


def parse_tags(
    value: str,
) -> list[str]:
    return [
        tag.strip()
        for tag in value.split(",")
        if tag.strip()
    ]


def empty_to_none(
    value: str,
) -> str | None:
    cleaned_value = value.strip()

    return cleaned_value or None


def build_form_task(
    *,
    existing_task: object,
    **form_values: object,
) -> object:
    class FormTask:
        pass

    task = FormTask()

    for attribute_name, attribute_value in vars(
        existing_task
    ).items():
        setattr(
            task,
            attribute_name,
            attribute_value,
        )

    for field_name, field_value in form_values.items():
        setattr(
            task,
            field_name,
            field_value,
        )

    task.status = form_values["task_status"]

    return task

@router.post(
    "/tasks/{task_id}/dependencies",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def add_task_dependency(
    task_id: int,
    depends_on_task_id: int = Form(...),
    created_by: str = Form(
        default="Kiran"
    ),
    dependency_service: (
        TaskDependencyService
    ) = Depends(
        get_task_dependency_service
    ),
) -> HTMLResponse:

    try:
        dependency_service.add_dependency(
            TaskDependencyCreate(
                task_id=task_id,
                depends_on_task_id=(
                    depends_on_task_id
                ),
                created_by=(
                    created_by.strip()
                    or "Kiran"
                ),
            )
        )

    except ValueError as error:

        return RedirectResponse(
            url=(
                f"/tasks/{task_id}"
                f"?dependency_error="
                f"{quote(str(error))}"
            ),
            status_code=303,
        )

    return RedirectResponse(
        url=(
            f"/tasks/{task_id}"
            "?dependency_added=true"
        ),
        status_code=303,
    )

@router.post(
    "/tasks/{task_id}/dependencies/{dependency_id}/delete",
    include_in_schema=False,
)
def remove_task_dependency(
    task_id: int,
    dependency_id: int,
    dependency_service: TaskDependencyService = Depends(
        get_task_dependency_service
    ),
):
    dependency_service.remove_dependency(
        dependency_id=dependency_id,
        removed_by="Kiran",
    )

    return RedirectResponse(
        url=f"/tasks/{task_id}?dependency_removed=true",
        status_code=303,
    )